package com.pass.examenpmdmt1;

public interface Actualizacion {
    public void recuperarDatos(Camaras c);
}
